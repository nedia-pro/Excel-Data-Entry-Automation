
Project: Excel Data Entry Automation

Description:
This Python script automatically adds a new employee record to the Excel file "employees.xlsx".
If the file does not exist, it creates one with the appropriate headers.

How to run:
1. Make sure you have Python installed (version 3.x)
2. Install openpyxl library if you don’t have it:
   pip install openpyxl
3. Run the script:
   python add_employee.py

You can modify the 'new_employee' list in the script to add different data.
