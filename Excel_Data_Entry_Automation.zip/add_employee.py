
import openpyxl

# اسم ملف الإكسل
filename = 'employees.xlsx'

# تحميل ملف الإكسل أو إنشاؤه لو مش موجود
try:
    wb = openpyxl.load_workbook(filename)
except FileNotFoundError:
    wb = openpyxl.Workbook()

sheet = wb.active
sheet.title = 'Employees'

# إضافة رؤوس الأعمدة لو الجدول فاضي
if sheet.max_row == 1 and sheet.max_column == 1 and sheet['A1'].value is None:
    sheet.append(['Name', 'Age', 'Salary'])

# بيانات جديدة للإضافة
new_employee = ['John Doe', 30, 45000]

# إضافة صف جديد
sheet.append(new_employee)

# حفظ الملف
wb.save(filename)
print(f'Added new employee {new_employee[0]} to {filename}')
